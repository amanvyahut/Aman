package com.tscric.lora;

import android.app.Activity;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    // TODO: Replace with your Firebase project's WEB client ID.
    // Firebase Console -> Authentication -> Sign-in method -> Google -> Web SDK configuration
    // -> "Web client ID" (looks like 1234567890-xxxxxxxx.apps.googleusercontent.com)
    private static final String WEB_CLIENT_ID = "REPLACE_WITH_YOUR_FIREBASE_WEB_CLIENT_ID.apps.googleusercontent.com";

    private WebView webView;
    private CredentialManager credentialManager;
    private final Executor mainExecutor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        enableImmersiveMode();
        setContentView(R.layout.activity_main);

        credentialManager = CredentialManager.create(this);

        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // Local asset only needs local file access, not universal cross-origin file access.
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new JsBridge(), "AndroidAuth");
        webView.loadUrl("file:///android_asset/index.html");
    }

    /** Bridge exposed to the WebView JS as window.AndroidAuth */
    private class JsBridge {
        @JavascriptInterface
        public void signIn() {
            runOnUiThread(MainActivity.this::launchGoogleSignIn);
        }

        @JavascriptInterface
        public void signOut() {
            runOnUiThread(() -> {
                try {
                    credentialManager.clearCredentialStateAsync(
                            new androidx.credentials.ClearCredentialStateRequest(),
                            new CancellationSignal(),
                            mainExecutor,
                            new CredentialManagerCallback<Void, androidx.credentials.exceptions.ClearCredentialException>() {
                                @Override public void onResult(Void result) { }
                                @Override public void onError(androidx.credentials.exceptions.ClearCredentialException e) { }
                            });
                } catch (Exception ignored) { }
            });
        }
    }

    private void launchGoogleSignIn() {
        try {
            GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(WEB_CLIENT_ID)
                    .setNonce(UUID.randomUUID().toString())
                    .build();

            GetCredentialRequest request = new GetCredentialRequest.Builder()
                    .addCredentialOption(option)
                    .build();

            credentialManager.getCredentialAsync(
                    this,
                    request,
                    new CancellationSignal(),
                    mainExecutor,
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override
                        public void onResult(GetCredentialResponse response) {
                            try {
                                GoogleIdTokenCredential cred = GoogleIdTokenCredential.createFrom(
                                        response.getCredential().getData());
                                String idToken = cred.getIdToken();
                                runOnUiThread(() -> sendToJs("onGoogleAuthSuccess", idToken));
                            } catch (Exception e) {
                                Log.e("MainActivity", "Credential parse failed", e);
                                runOnUiThread(() -> sendToJs("onGoogleAuthError", "Parse failed"));
                            }
                        }

                        @Override
                        public void onError(GetCredentialException e) {
                            Log.e("MainActivity", "Sign-in failed", e);
                            runOnUiThread(() -> sendToJs("onGoogleAuthError", String.valueOf(e.getMessage())));
                        }
                    });
        } catch (Exception e) {
            Log.e("MainActivity", "Sign-in launch failed", e);
            sendToJs("onGoogleAuthError", String.valueOf(e.getMessage()));
        }
    }

    private void sendToJs(String fn, String arg) {
        String safeArg = arg == null ? "" : arg.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "");
        webView.evaluateJavascript("javascript:window." + fn + "('" + safeArg + "')", null);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enableImmersiveMode();
    }

    private void enableImmersiveMode() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
}
