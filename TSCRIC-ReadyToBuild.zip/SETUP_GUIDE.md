# TSCRIC Ludo — Security & Google Sign-In Setup

Code taraf se sab ready hai. Bas 3 jagah tumhe Firebase/Google console me manually
setup karna hoga — ye sirf ek baar karna hai.

## 1. Firebase Console me Google Sign-In enable karo

1. https://console.firebase.google.com → project **talkzone-b3488** kholo
2. **Authentication → Sign-in method** → **Google** provider ko **Enable** karo
3. Save karne ke baad wahi page pe "Web SDK configuration" section me ek
   **Web client ID** dikhega (format: `xxxxxxxxx-xxxxxxxx.apps.googleusercontent.com`)
   — ise copy kar lo.

## 2. App me Web Client ID paste karo

File: `app/src/main/java/com/tscric/lora/MainActivity.java`

```java
private static final String WEB_CLIENT_ID = "REPLACE_WITH_YOUR_FIREBASE_WEB_CLIENT_ID.apps.googleusercontent.com";
```

Yahan apna copy kiya hua Web Client ID paste kar do.

## 3. SHA-1 fingerprint register karo (Android OAuth client ke liye)

Is repo me ek **fixed debug.keystore** (`app/debug.keystore`) already committed hai
taaki GitHub Actions har build me same SHA-1 use kare (varna Google Sign-In
random tootega har naye build pe).

Iska fingerprint:
```
SHA1: 91:88:8F:31:CC:5A:E7:10:7E:90:B8:B7:09:AD:6A:74:80:ED:2F:B6
```

Steps:
1. Firebase Console → ⚙️ **Project settings** → scroll to "Your apps"
2. Agar Android app (`com.tscric.lora`) already registered nahi hai, to **Add app → Android**
   → package name `com.tscric.lora` daal ke add karo
3. Us Android app card me **Add fingerprint** pe click karo → upar wala SHA1 paste karo → Save
4. Google Cloud Console (auto-linked) me ye Android OAuth client apne aap ban jaayega

Bas — koi `google-services.json` download/add karne ki zaroorat nahi, kyunki
sign-in Credential Manager se ho raha hai (lightweight, Firebase Android SDK
use nahi kar rahe).

## 4. Realtime Database Security Rules apply karo

1. Firebase Console → **Realtime Database → Rules** tab
2. Is repo ki `firebase-rules.json` file ka pura content copy karo
3. Paste karke **Publish** kar do

Ye rules ensure karte hain:
- Koi bhi data tabhi read/write ho sakta hai jab user **Google se sign-in** ho (`auth != null`)
- Har user apna `users/{uid}` profile sirf khud edit kar sakta hai, dusron ka nahi
- Username claim (`usernames/{username}`) atomic hai — ek username sirf ek hi uid claim kar sakta hai, koi overwrite nahi kar sakta
- Presence (`ludo3_users/{uid}`) bhi sirf apna uid likh sakta hai

**Note:** Game rooms (`ludo3/*`) aur chat sirf "signed-in hona chahiye" tak restrict
kiye hain (`auth != null`), per-player-in-room tak nahi — kyunki gameplay ke
beech-beech me kai sub-paths update hote hain aur usse tighter rule likhne ke
liye poore game-state write-flow ka gehra audit chahiye. Ye already un-authenticated
public access ko poori tarah band kar deta hai, jo abhi sabse bada gap tha.

## 5. Build & test

Normal tarike se push karo — GitHub Actions `assembleDebug` chalayega aur
Release me APK mil jayega, ab har build me same signing key (fixed SHA-1) use
hoga.

Install karke test karo:
1. App khole → "Sign in with Google" dabao → apna Google account choose karo
2. Pehli baar sign-in pe unique `@username` choose karne ko milega
3. Doosri baar app kholo to seedha sign-in ho jayega, username/profile yaad rahega
4. Search Players me `@username` se doosre online players dhoond sakte ho

## Baaki improvements is update me already ho chuke:
- Location permissions hata diye (game ko chahiye nahi thi)
- WebView ki `allowUniversalAccessFromFileURLs` band ki (attack surface kam)
- Premium glass/blur UI + ambient animated background add kiya
- Search ab `@username` (unique, permanent) se hoti hai, sirf display name se nahi
- Sign-out option add kiya (profile chip pe tap karke)
