# TSCRIC Ludo — Public Launch Guide

Ye guide un cheezo ko cover karta hai jo already done hain (Google Sign-In,
security rules) aur unko jo **public/Play-Store launch ke liye** karne baaki hain.

---

## ✅ Already done (code-side)

- Google Sign-In (Credential Manager) + unique permanent `@username`
- Firebase Realtime Database rules — bina login koi data touch nahi kar sakta,
  ab game rooms aur chat bhi sirf actual room-players tak restricted hain
  (pehle koi bhi signed-in user kisi bhi room ka data chhed sakta tha)
- Basic profanity filter — username aur chat dono me
- Debug build ka fixed SHA-1 (testing/sideload ke liye)
- Production-grade **release signing** support add kiya (neeche step 1)

## ⚠️ Naya security note
Room ke andar player ka ID ab tumhara **Google account ka UID** hai (pehle
random tha) — isse rules tight ho paaye. Agar tumne is se pehle wali build
already use kar rakhi hai, purane ongoing rooms naye build ke saath compatible
nahi honge (bas naye games banao, purana koi data loss nahi hoga).

---

## 1. Production release signing (zaroori — Play Store ke liye)

Debug key se Play Store pe app publish **nahi** ho sakta, aur agar debug key
kabhi leak ho (jo GitHub public repo me committed hai), koi bhi fake update
sign kar sakta hai. Isliye ek **alag, private release key** banaya hai — ye
kabhi bhi repo me commit NAHI karna.

**GitHub Secrets me add karo** (Repo → Settings → Secrets and variables →
Actions → New repository secret):

| Secret name | Value |
|---|---|
| `RELEASE_KEYSTORE_BASE64` | `release-keystore/release.keystore.base64` file ka pura content |
| `RELEASE_KEYSTORE_PASSWORD` | `TscricLudo@2026Prod` |
| `RELEASE_KEY_ALIAS` | `tscric_release` |
| `RELEASE_KEY_PASSWORD` | `TscricLudo@2026Prod` |

⚠️ **Ye password badal do apne khud ke strong password se** — maine ek default
generate kiya hai, production ke liye apna unique password use karo (naya
keystore khud bhi generate kar sakte ho `keytool` se agar chaho).

Secrets add karne ke baad, agli push pe workflow apne aap **release-signed
APK** bhi banayega (Release me `ludo-release.apk` naam se milega, saath me
`ludo-debug.apk` bhi rahega testing ke liye).

**Iske release key ka SHA-1** bhi Firebase me add karna hoga (Step 2 jaisa hi,
General → Your apps → Android app → Add fingerprint) — nahi to release build
me Google Sign-In fail hoga:
```
SHA1: 9C:AC:7B:3E:F0:35:63:AA:99:33:29:7E:EC:C8:D4:EC:4F:B6:36:D4
```

## 2. Firebase plan upgrade (Blaze)

Abhi tum **Spark (free)** plan pe ho — screenshot me dikha. Free plan me
Realtime Database ke daily read/write/download limits hain; real public users
aane pe ye jaldi khatam ho sakte hain aur app down dikhega.

- Firebase Console → bottom-left "Upgrade" → **Blaze (pay as you go)** plan pe jao
- Blaze me bhi wahi free quota milta hai, bas limit cross hone pe app band
  hone ki jagah thoda charge lagta hai (chhoti app ke liye generally
  ₹0-few hundred/month tak hi rehta hai) — set a budget alert to be safe

## 3. Privacy Policy publish karo

`privacy-policy.html` file di hai — isme `[DATE]` aur `[YOUR EMAIL]` fill karo,
phir apni GitHub Pages site pe daal do (tumhare paas already
`amanvyahut.github.io` hai) — link kuch aisa banega:
`https://amanvyahut.github.io/ludo-privacy-policy.html`

Play Store submission me ye link dena **compulsory** hai kyunki app Google
account data collect karta hai.

## 4. Play Console pe publish

1. https://play.google.com/console → Developer account banao (one-time $25 fee)
2. New app → details fill karo, Privacy Policy link do (step 3 wala)
3. Release-signed APK/AAB upload karo (Step 1 wala `ludo-release.apk`,
   ya better: Gradle se AAB banao Play ke liye — chaho to bata dena, wo bhi
   set up kar dunga)
4. "Data safety" form bharo — batana hoga app kya collect karta hai (name,
   email, gameplay data — jaisa privacy policy me likha hai)
5. Content rating questionnaire bharo
6. Review ke liye submit karo (Google ko kuch din lagte hain first review me)

## 5. Abuse protection (recommended, launch ke baad bhi kar sakte ho)

- **Firebase App Check** laga do (Play Integrity provider) — isse fake/bot
  clients ka database access rok sakte ho. Blaze plan chahiye, thoda setup hai —
  bolo to next step me kar dete hain.
- Profanity filter abhi basic hai (client-side wordlist) — koi determined user
  bypass kar sakta hai. Agar chat pe zyada bharosa chahiye to Cloud Function
  se server-side filtering add ki ja sakti hai.

---

## Quick recap — kya already secure hai vs kya baaki hai

| Cheez | Status |
|---|---|
| Fake profile / no-auth access | Fixed (Google Sign-In) |
| Database open to anyone | Fixed (rules) |
| Room/chat cross-access by strangers | Fixed (uid-based rules) |
| Debug key security risk | Fixed (release signing set up — secrets add karne baaki) |
| Free-plan quota risk at scale | Tumhe Blaze upgrade karna hoga |
| Play Store compliance (privacy policy, data safety) | Tumhe fill/publish karna hoga |
| Bot/abuse protection (App Check) | Optional next step |

Sabse pehle **Step 1 (release signing secrets)** aur **Step 2 (Blaze upgrade)**
kar lo — ye do sabse zaroori hain public launch se pehle. Baaki (Play Store
submission) apni marzi se jab ready ho tab karna.
